"""
    This module displays common usage of the package
    :copyright: (c) 2014 by Kourosh Parsa.
"""
import iis_bridge as iis
from iis_bridge import pool
from iis_bridge import site
from iis_bridge import isapi
#pool.create("abc", pipeline_mode="Classic")
#pool.config("abc", thirty_two_bit=True, identity="LocalSystem")
#pool.config("abc", thirty_two_bit=True, identity="NetworkService", loadUserProfile=True)
#pool.config("abc", thirty_two_bit=True, identity="Custom", username="administrator", password="pass")
#pool.config("abc", ping_enabled=True, ping_period=40, ping_response_time=35)
#isapi.enable()
#pool.restart("abc")
#iis.iisreset()
#pool.delete("abc")

#site.create("abc", 303, "C:\\inetpub\wwwroot\\abc", "abc")
#pool.config("abc", thirty_two_bit=True)
#site.stop("abc")
#site.start("abc")
#site.delete("abc")
#pool.delete("abc")
